export const SET_AMOUNT2 = "SET_AMOUNT2";
export const SET_AMOUNT1 = "SET_AMOUNT1";
