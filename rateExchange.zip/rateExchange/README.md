# exchange-rate

To run the project:

1. Clone this repo
2. Run `npm install`
3. Run `npm start`
